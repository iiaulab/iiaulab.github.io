
num = 12;

imageRGB = imread([int2str(num) '.bmp']);
imageSize = [ size(imageRGB,1) size(imageRGB,2) ];
figure('position',[ 0 0 imageSize(2) imageSize(1) ]); 
set(gcf,'DoubleBuffer','on','MenuBar','none');
pause;
axes(axes('position', [0 0 1.0 1.0]));
imagesc(imageRGB, [0,1]); 

temp = importdata([int2str(10) '.txt']);                            %%����Label�ļ�����ȡ�������������洢

targetWindowSize = [ abs(temp(1,2)-temp(1,1)+1),abs(temp(1,4)-temp(1,3)+1) ];           %%��ȡĿ���С
targetWindowSize = [ 2*floor(targetWindowSize(1)/2) 2*floor(targetWindowSize(2)/2) ];   %%Ŀ����С��׼��
targetLocation = [ round((temp(1,1)+temp(1,2))/2),round((temp(1,3)+temp(1,4))/2) ];     %%��ȡĿ������λ��
rmin = targetLocation(1) - targetWindowSize(1)/2;                   %%Ŀ��ı߽����
rmax = targetLocation(1) + targetWindowSize(1)/2;                   %%-------------
cmin = targetLocation(2) - targetWindowSize(2)/2;                   %%-------------
cmax = targetLocation(2) + targetWindowSize(2)/2;                   %%Ŀ��ı߽����
drawBoundingBox(rmin,rmax,cmin,cmax,'r');                           %%��ʾĿ���
[ rmin rmax cmin cmax ]

[x,y,c] = ginput(1);
targetLocation = [ y x ];
rmin = targetLocation(1) - targetWindowSize(1)/2;                   %%Ŀ��ı߽����
rmax = targetLocation(1) + targetWindowSize(1)/2;                   %%-------------
cmin = targetLocation(2) - targetWindowSize(2)/2;                   %%-------------
cmax = targetLocation(2) + targetWindowSize(2)/2;                   %%Ŀ��ı߽����
drawBoundingBox(rmin,rmax,cmin,cmax,'b');                           %%��ʾĿ���
[ rmin rmax cmin cmax ]
pause;